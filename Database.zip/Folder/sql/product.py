SQL_CREATE_TABLE = """
    CREATE TABLE IF NOT EXISTS product(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    price REAL NOT NULL, 
    description TEXT NOT NULL)
"""

SQL_INSERT = """
    INSERT INTO product(name, price, description)
    VALUES (?, ?, ?)
"""

SQL_GET_ALL= """
    SELECT id, name, price, description
    FROM product
    ORDER BY name
"""