import sqlite3
from typing import List, Optional
from models.product import Product
from sql.product import * 
from util.database import create_connection


class ProductRepo:
    @classmethod
    def create_table(cls) -> bool:
        try:
            with create_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(SQL_CREATE_TABLE)
                return True
        except sqlite3.Error as ex:
            print(ex)
            return False
        

    @classmethod
    def insert(cls, product:Product) -> Optional[Product]:
        try:
            with create_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(SQL_INSERT, (
                    product.name,
                    product.price,
                    product.description
                ))
                if cursor.rowcount > 0:
                    product.id = cursor.lastrowid
                    return product
        except sqlite3.Error as ex:
            print(ex)
            return None
        

    @classmethod
    def get_all(cls) -> List[Product]:
        try:
            with create_connection() as conn:
                cursor = conn.cursor()
                tuples = cursor.execute(SQL_GET_ALL).fetchall()
                products = [Product (*t) for t in tuples]
                return products
        except sqlite3.Error as ex:
            print(ex)
            return None
        

