from models.product import Product
from repo.product import ProductRepo

ProductRepo.create_table()

#p1 = Product(name="Banana", price=4.5, description="Banana from Iconha")
#p2 = Product(name="Pineapple", price=7.6, description="Pineaple from Marataízes")
#p3 = Product(name="Strawberry", price=11.9, description="Strawberry from Venda Nova")

#p1 = ProductRepo.insert(p1)
#p2 = ProductRepo.insert(p2)
#p3 = ProductRepo.insert(p3)

#print(p1.id, p1.name, p1.price, p1.description)
#print(p2.id, p2.name, p2.price, p2.description)
#print(p3.id, p3.name, p3.price, p3.description)

while True:
    name= input("Product name (ENTER to exit):")
    if not name:
        break
    price = float(input("Product price:"))
    description = input("Product description:")
    p = Product(name=name, price=price, description=description)
    ProductRepo.insert(p)

products = ProductRepo.get_all()
print ("Products in Database")
print ("-----------------------------")
for p in products:
    print(p.id, p.name, p.price, p.description)