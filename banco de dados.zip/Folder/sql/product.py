SQL_CREATE_TABLE = """
    CREATE TABLE IF NOT EXISTS product(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    price REAL NOT NULL, 
    description TEXT NOT NULL)
"""
#same order for create a table (sql/product.py) and take the parameters in the class (models/product.py)

SQL_INSERT = """
    INSERT INTO product(name, price, description)
    VALUES (?, ?, ?)
"""

SQL_GET_ALL= """
    SELECT id, name, price, description
    FROM product
    ORDER BY name
"""

SQL_UPDATE = """
    UPDATE product
    SET name=?, price=?, description=?
    WHERE id=?
"""

SQL_DELETE ="""
    DELETE FROM product
    WHERE id=?
"""

SQL_GET_ONE = """
    SELECT id, name, price, description
    FROM product
    WHERE id=?
"""

SQL_GET_COUNT = """
    SELECT COUNT (*) FROM product 
"""