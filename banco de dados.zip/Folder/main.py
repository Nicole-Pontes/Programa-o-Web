import os
from models.product import Product
from repo.product import ProductRepo

ProductRepo.create_table()

def insert_product ():
    print("Inserting Product")
    print("-----------------")
    name = input("Name: ")
    price = input("Price: ")
    description = input("Description: ")
    product = Product(None, name, price, description)
    ProductRepo.insert(product)

def list_product():
    print("Listin Products")
    print("---------------")
    print("ID|NAME")
    products = ProductRepo.get_all()
    for p in products:
        print(f"{p.id:02d}|{p.name}")

def update_product():
    print("Updating Product")
    print("----------------")
    id = int(input("Product id: "))
    original_product = ProductRepo.get_one(id)
    new_name = input(f"New name({original_product.name}): ")
    new_price = float(input(f"New price ({original_product.price}): "))
    new_description = input(f"New description ({original_product.description}): ")
    update_product = Product(id, new_name, new_price, new_description)
    ProductRepo.update(update_product)


def delete_product():
    print("Deleting Product")
    print("----------------")
    id = int(input("Product id: "))
    product = ProductRepo.get_one(id)
    answer = input(f"Are you sure to delete the product '{product.name}'? (Y/N): ")
    if answer.upper() == "Y":
        ProductRepo.delete(id)

def show_product():
    print("Showing Product")
    print("---------------")
    id = int(input("Product id: "))
    product = ProductRepo.get_one(id)
    print(f"Name: {product.name}")
    print(f"Price: {product.price}")
    print(f"Description: {product.description}")
    

def show_menu():
    print("SuperHyperSkyIsTheLimitSystem")
    print("-----------------------------")
    print("1. Insert Product")
    print("2. List Products")
    print("3. Update Product")
    print("4. Delete Product")
    print("5. Show Product")
    print("6. Exit")


def get_user_options() -> int:
    option = int(input("Desired Option "))
    return option

def clear_screen():
    os.system("cls")

def wait_return_key():
    print("-------------------------")
    print("Press RETURN to continue...")
    input()

while True:
    clear_screen()
    show_menu()
    option = get_user_options()
    clear_screen()
    match(option):
        case 1: insert_product()
        case 2: list_product()
        case 3: update_product()
        case 4: delete_product()
        case 5: show_product
        case 6: break
        case _: print("Invalid option!")
    wait_return_key()
print("Thanks for using this program!")



#Customer: id, name, phone, email, address, password, and at least one improvement