from dataclasses import dataclass
from typing import Optional


@dataclass
class Product:
    id: Optional[int] = None
    name: Optional[str] = None
    price: Optional[float] = None
    description: Optional[str] = None

#same order for create a table (sql/product.py) and take the parameters in the class (models/product.py)